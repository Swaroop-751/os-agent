"""
audit.py — Structured audit logging for GenAI Linux Agent.

Two log functions:
  audit_log()   — normal plan/apply events (existing)
  blocked_log() — security-blocked events (new)

Both write to logs/audit.jsonl as newline-delimited JSON.
"""

import json
import time
from pathlib import Path
import os

# ─────────────────────────────────────────────────────────────────────────────
# Log file location
# ─────────────────────────────────────────────────────────────────────────────

LOG = Path(os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs", "audit.jsonl"))
LOG.parent.mkdir(parents=True, exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _write(entry: dict) -> None:
    """Append a JSON line to the audit log (thread-safe append mode)."""
    with open(LOG, "a") as f:
        f.write(json.dumps(entry) + "\n")


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def audit_log(**kwargs) -> None:
    """
    Log a normal agent event (PLAN, APPLY, etc.).
    Automatically stamps a Unix timestamp.
    """
    _write({"ts": time.time(), **kwargs})


def blocked_log(
    *,
    user: str,
    role: str,
    reason: str,
    raw_message: str = "",
    blocked_cmd: str = "",
    check: str = "",
) -> None:
    """
    Log a security-blocked event with full context so every attempted
    violation is visible in the audit trail.

    Args:
        user:         Requesting user identifier
        role:         Claimed role at time of request
        reason:       Human-readable block reason (from PermissionError)
        raw_message:  Original English instruction from the user
        blocked_cmd:  The shell command that was blocked (if available)
        check:        Which security check triggered the block
    """
    _write({
        "ts": time.time(),
        "event": "BLOCKED",
        "user": user,
        "role": role,
        "check": check,
        "reason": reason,
        "raw_message": raw_message,
        "blocked_cmd": blocked_cmd,
    })
