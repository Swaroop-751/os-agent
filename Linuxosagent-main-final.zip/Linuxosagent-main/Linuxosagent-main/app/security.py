"""
security.py — Security enforcement layer for GenAI Linux Agent.

All checks are purely defensive add-ons. Nothing here changes how the
agent plans or applies commands; it only blocks what should never run.
"""

import re
import time
from collections import defaultdict, deque
from typing import Optional

from app.policy import POL

# ─────────────────────────────────────────────────────────────────────────────
# Rate limiter (in-memory sliding window, per user)
# ─────────────────────────────────────────────────────────────────────────────
_RATE_LIMIT_MAX = 10          # max requests per window
_RATE_LIMIT_WINDOW = 60       # window size in seconds
_user_timestamps: dict = defaultdict(deque)


def rate_limit_check(user: str) -> None:
    """
    Sliding-window rate limiter.
    Raises PermissionError if a user exceeds _RATE_LIMIT_MAX plan
    requests within _RATE_LIMIT_WINDOW seconds.
    """
    now = time.monotonic()
    dq = _user_timestamps[user]

    # Drop timestamps outside the window
    while dq and now - dq[0] > _RATE_LIMIT_WINDOW:
        dq.popleft()

    if len(dq) >= _RATE_LIMIT_MAX:
        raise PermissionError(
            f"Rate limit exceeded: max {_RATE_LIMIT_MAX} requests "
            f"per {_RATE_LIMIT_WINDOW}s. Try again later."
        )

    dq.append(now)


# ─────────────────────────────────────────────────────────────────────────────
# Input sanitisation — raw user message
# ─────────────────────────────────────────────────────────────────────────────
# Characters that have no place in a plain English instruction
_DANGEROUS_CHARS_RE = re.compile(
    r"[`$\x00-\x08\x0b-\x0c\x0e-\x1f\x7f]"
)


def sanitize_message(message: str) -> str:
    """
    Validate the raw English instruction before it reaches the LLM.
    - Enforces max message length from policy
    - Rejects obvious shell-metacharacter injection attempts
    Returns the (unchanged) message if clean, raises ValueError otherwise.
    """
    safety = POL.get("safety", {})
    max_len = safety.get("max_message_length", 1000)

    if len(message) > max_len:
        raise ValueError(
            f"Message too long ({len(message)} chars). "
            f"Maximum allowed: {max_len}."
        )

    if _DANGEROUS_CHARS_RE.search(message):
        raise ValueError(
            "Message contains disallowed characters (shell metacharacters "
            "or control characters)."
        )

    return message


# ─────────────────────────────────────────────────────────────────────────────
# Prompt-injection detection — raw user message
# ─────────────────────────────────────────────────────────────────────────────

def detect_prompt_injection(message: str) -> None:
    """
    Check the English instruction for known jailbreak / prompt-injection
    phrases before they reach the LLM.
    Raises PermissionError if any phrase is detected.
    """
    lower = message.lower()
    phrases = (
        POL.get("safety", {}).get("prompt_injection_phrases", [])
    )
    for phrase in phrases:
        if phrase.lower() in lower:
            raise PermissionError(
                f"Blocked: message contains a disallowed phrase "
                f"({phrase!r}). Prompt injection is not permitted."
            )


# ─────────────────────────────────────────────────────────────────────────────
# Privilege-escalation check — generated shell command
# ─────────────────────────────────────────────────────────────────────────────

def check_privilege_escalation(cmd: str) -> None:
    """
    Block commands that attempt privilege escalation (sudo, su, pkexec,
    setuid bits, chown root, etc.).
    Raises PermissionError on match.
    """
    patterns = POL.get("safety", {}).get("privilege_patterns", [])
    cmd_lower = cmd.lower()
    for pat in patterns:
        if pat.lower() in cmd_lower:
            raise PermissionError(
                f"Blocked: privilege escalation attempt detected "
                f"(matched pattern: {pat!r})."
            )


# ─────────────────────────────────────────────────────────────────────────────
# Obfuscation / code-injection check — generated shell command
# ─────────────────────────────────────────────────────────────────────────────

def check_injection_obfuscation(cmd: str) -> None:
    """
    Block commands that use code-injection or obfuscation techniques
    (base64 decode-pipe, eval, python/perl -e, /dev/tcp shells, etc.).
    Raises PermissionError on match.
    """
    patterns = POL.get("safety", {}).get("injection_patterns", [])
    cmd_lower = cmd.lower()
    for pat in patterns:
        if pat.lower() in cmd_lower:
            raise PermissionError(
                f"Blocked: code-injection / obfuscation technique detected "
                f"(matched pattern: {pat!r})."
            )


# ─────────────────────────────────────────────────────────────────────────────
# Protected-path check — generated shell command
# ─────────────────────────────────────────────────────────────────────────────
# Write operators in shell commands
_WRITE_OPERATORS_RE = re.compile(
    r"(>|>>|tee\s|cp\s|mv\s|install\s|rsync\s|ln\s|touch\s|mkdir\s|"
    r"sed\s+-i|awk\s+.*>\s*|echo\s+.*>\s*)"
)


def check_path_traversal(cmd: str) -> None:
    """
    Block commands that try to write to protected filesystem paths
    (/etc, /boot, /root, /sys, /proc, /dev, ~/.ssh, etc.).
    Only flagged when a write operator is present in the command.
    Raises PermissionError on match.
    """
    # Only check if the command contains a write-like operation
    if not _WRITE_OPERATORS_RE.search(cmd):
        return

    protected = POL.get("safety", {}).get("protected_write_paths", [])
    for path in protected:
        if path in cmd:
            raise PermissionError(
                f"Blocked: attempt to write to a protected path "
                f"({path!r} is off-limits)."
            )


# ─────────────────────────────────────────────────────────────────────────────
# Allowlist enforcement — generated shell command vs role
# ─────────────────────────────────────────────────────────────────────────────

def _matches_any(cmd: str, patterns: list) -> bool:
    """Return True if cmd starts with (or contains) any allowlist pattern."""
    cmd_stripped = cmd.strip()
    for pat in patterns:
        # fnmatch-style: trailing * means prefix match, else exact prefix
        pat_core = pat.rstrip("* ").strip()
        if cmd_stripped.startswith(pat_core):
            return True
    return False


def enforce_allowlist(cmd: str, role: str) -> None:
    """
    Enforce the allowlist from policy.yaml based on the caller's role:
      - viewer   → must match allowlist_read
      - operator → must match allowlist_read OR allowlist_write
      - admin    → no allowlist check (but all other checks still apply)
    Raises PermissionError if the command is not on the appropriate list.
    """
    if role == "admin":
        return  # admins bypass the allowlist (other checks still run)

    tool_cfg = POL.get("tools", {}).get("RunCommand", {})
    read_list = tool_cfg.get("allowlist_read", [])
    write_list = tool_cfg.get("allowlist_write", [])

    if role == "viewer":
        if not _matches_any(cmd, read_list):
            raise PermissionError(
                f"Blocked: command not on the viewer read-allowlist. "
                f"Viewers may only run approved read-only commands."
            )
    elif role == "operator":
        if not _matches_any(cmd, read_list) and not _matches_any(cmd, write_list):
            raise PermissionError(
                f"Blocked: command not on the operator allowlist. "
                f"Operators may only run approved commands."
            )
    else:
        # Unknown role — already rejected at HTTP layer, but fail-safe here
        raise PermissionError(
            f"Blocked: unknown role {role!r}. "
            f"Allowed roles: viewer, operator, admin."
        )


# ─────────────────────────────────────────────────────────────────────────────
# Master validator — call this for every command before execution
# ─────────────────────────────────────────────────────────────────────────────

def validate_command(cmd: str, role: str) -> None:
    """
    Run every command-level security check in order:
      1. Blocked destructive patterns (existing)
      2. Privilege escalation
      3. Obfuscation / injection
      4. Protected path traversal
      5. Allowlist enforcement

    Raises PermissionError with a clear reason on any violation.
    Does NOT change how commands are executed — purely a gate.
    """
    from app.policy import matches_blocked  # avoid circular import at module level

    # 1. Existing blocked-pattern check
    if matches_blocked(cmd):
        raise PermissionError(
            "Blocked: command matches a hard-blocked dangerous pattern."
        )

    # 2. Privilege escalation
    check_privilege_escalation(cmd)

    # 3. Obfuscation / code injection
    check_injection_obfuscation(cmd)

    # 4. Protected path traversal
    check_path_traversal(cmd)

    # 5. Allowlist
    enforce_allowlist(cmd, role)


def validate_message(message: str) -> str:
    """
    Run every message-level security check:
      1. Sanitise (length + bad chars)
      2. Prompt-injection detection

    Returns the clean message, or raises ValueError / PermissionError.
    """
    msg = sanitize_message(message)
    detect_prompt_injection(msg)
    return msg
