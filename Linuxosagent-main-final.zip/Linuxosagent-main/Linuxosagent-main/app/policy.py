"""
policy.py — Policy loader and validator for GenAI Linux Agent.

validate_step_against_policy() is the single enforcement gate called
before any command is executed. It delegates all checks to security.py.
"""

import yaml
import os

# ─────────────────────────────────────────────────────────────────────────────
# Load policy once at startup
# ─────────────────────────────────────────────────────────────────────────────

def load_policy():
    policy_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "policy.yaml")
    with open(policy_path) as f:
        return yaml.safe_load(f)

POL = load_policy()


# ─────────────────────────────────────────────────────────────────────────────
# Basic blocked-pattern check (used by security.py too, kept here to avoid
# circular imports)
# ─────────────────────────────────────────────────────────────────────────────

def matches_blocked(cmd: str) -> bool:
    """
    Return True if cmd matches any hard-blocked destructive pattern
    OR exceeds the maximum allowed command length.
    """
    safety = POL.get("safety", {})

    # Check hard-blocked patterns (case-insensitive substring match)
    for pat in safety.get("blocked_patterns", []):
        if pat.lower() in cmd.lower():
            return True

    # Enforce max command length
    if len(cmd) > safety.get("max_cmd_length", 500):
        return True

    return False


# ─────────────────────────────────────────────────────────────────────────────
# Role helpers
# ─────────────────────────────────────────────────────────────────────────────

def role_requires_approval(role: str) -> bool:
    """Always True — every role requires human approval for safety."""
    return True


def is_valid_role(role: str) -> bool:
    """Return True if role is declared in policy.yaml valid_roles list."""
    return role in POL.get("valid_roles", ["viewer", "operator", "admin"])


# ─────────────────────────────────────────────────────────────────────────────
# Master step validator — called before every command is executed
# ─────────────────────────────────────────────────────────────────────────────

def validate_step_against_policy(step: dict, role: str = "operator") -> None:
    """
    Validate a planned step against all security policies.

    Only RunCommand steps are supported; any other tool is rejected.
    Delegates all command-level checks to security.validate_command()
    so that every layer (blocked patterns, privilege escalation,
    obfuscation, path traversal, allowlist) is applied consistently.

    Raises PermissionError with a descriptive reason on any violation.
    """
    if step.get("tool") != "RunCommand":
        raise PermissionError(
            f"Blocked: unsupported tool {step.get('tool')!r}. "
            "Only the RunCommand tool is permitted."
        )

    cmd = step.get("args", {}).get("cmd", "")
    if not cmd.strip():
        raise PermissionError("Blocked: empty command.")

    # Delegate to the full security stack
    from app.security import validate_command  # imported here to avoid circular
    validate_command(cmd, role)
